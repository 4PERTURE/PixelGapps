#!/sbin/sh
# 
# ADDOND_VERSION=2
# 
# /system_root/system/addon.d/70-gapps.sh
#
. /tmp/backuptool.functions

if [ -z $backuptool_ab ]; then
  SYS=$S
  TMP=/tmp
else
  SYS=/postinstall/system
  TMP=/postinstall/tmp
fi

list_files() {
cat <<EOF
app/CalculatorGooglePrebuilt/CalculatorGooglePrebuilt.apk
app/CalendarGooglePrebuilt/CalendarGooglePrebuilt.apk
app/Chrome/Chrome.apk
app/Drive/Drive.apk
app/EmergencyInfoGoogleNoUi/EmergencyInfoGoogleNoUi.apk
app/FaceLock/FaceLock.apk
app/GoogleContactsSyncAdapter/GoogleContactsSyncAdapter.apk
app/GoogleExtShared/GoogleExtShared.apk
app/GooglePrintRecommendationService/GooglePrintRecommendationService.apk
app/LatinIMEGooglePrebuilt/LatinIMEGooglePrebuilt.apk
app/Maps/Maps.apk
app/MarkupGoogle/MarkupGoogle.apk
app/NexusWallpapersStubPrebuilt2018/NexusWallpapersStubPrebuilt2018.apk
app/PlayGames/PlayGames.apk
app/PrebuiltBugle/PrebuiltBugle.apk
app/PrebuiltDeskClockGoogle/PrebuiltDeskClockGoogle.apk
app/PrebuiltGmail/PrebuiltGmail.apk
app/PrebuiltKeep/PrebuiltKeep.apk
app/SoundPickerPrebuilt/SoundPickerPrebuilt.apk
app/WebViewGoogle/WebViewGoogle.apk
app/YouTube/YouTube.apk
etc/default-permissions/default-permissions.xml
etc/default-permissions/opengapps-permissions.xml
etc/g.prop
etc/init.d/01_init
etc/init/vern-on-boot.rc
etc/permissions/com.google.android.dialer.support.xml
etc/permissions/com.google.android.maps.xml
etc/permissions/com.google.android.media.effects.xml
etc/permissions/privapp-permissions-google.xml
etc/permissions/split-permissions-google.xml
etc/preferred-apps/google.xml
etc/sysconfig/dialer_experience.xml
etc/sysconfig/google-hiddenapi-package-whitelist.xml
etc/sysconfig/google.xml
etc/sysconfig/google_build.xml
etc/sysconfig/google_exclusives_enable.xml
etc/vern.sh
framework/com.google.android.dialer.support.jar
framework/com.google.android.maps.jar
framework/com.google.android.media.effects.jar
lib/libfilterpack_facedetect.so
lib/libfrsdk.so
lib/libsketchology_native.so
lib64/libfacenet.so
lib64/libfilterpack_facedetect.so
lib64/libfrsdk.so
lib64/libsketchology_native.so
media/audio/alarms/A_real_hoot.ogg
media/audio/alarms/Bright_morning.ogg
media/audio/alarms/Cuckoo_clock.ogg
media/audio/alarms/Early_twilight.ogg
media/audio/alarms/Full_of_wonder.ogg
media/audio/alarms/Gentle_breeze.ogg
media/audio/alarms/Icicles.ogg
media/audio/alarms/Jump_start.ogg
media/audio/alarms/Loose_change.ogg
media/audio/alarms/Rolling_fog.ogg
media/audio/alarms/Spokes.ogg
media/audio/alarms/Sunshower.ogg
media/audio/notifications/Beginning.ogg
media/audio/notifications/Coconuts.ogg
media/audio/notifications/Duet.ogg
media/audio/notifications/End_note.ogg
media/audio/notifications/Gentle_gong.ogg
media/audio/notifications/Mallet.ogg
media/audio/notifications/Orders_up.ogg
media/audio/notifications/Ping.ogg
media/audio/notifications/Pipes.ogg
media/audio/notifications/Popcorn.ogg
media/audio/notifications/Shopkeeper.ogg
media/audio/notifications/Sticks_and_stones.ogg
media/audio/notifications/Tuneup.ogg
media/audio/notifications/Tweeter.ogg
media/audio/notifications/Twinkle.ogg
media/audio/ringtones/Copycat.ogg
media/audio/ringtones/Crackle.ogg
media/audio/ringtones/Flutterby.ogg
media/audio/ringtones/Hotline.ogg
media/audio/ringtones/Leaps_and_bounds.ogg
media/audio/ringtones/Lollipop.ogg
media/audio/ringtones/Lost_and_found.ogg
media/audio/ringtones/Mash_up.ogg
media/audio/ringtones/Monkey_around.ogg
media/audio/ringtones/Schools_out.ogg
media/audio/ringtones/The_big_adventure.ogg
media/audio/ringtones/Zen_too.ogg
media/audio/ui/ChargingStarted.ogg
media/audio/ui/Dock.ogg
media/audio/ui/Effect_Tick.ogg
media/audio/ui/InCallNotification.ogg
media/audio/ui/KeypressDelete.ogg
media/audio/ui/KeypressInvalid.ogg
media/audio/ui/KeypressReturn.ogg
media/audio/ui/KeypressSpacebar.ogg
media/audio/ui/KeypressStandard.ogg
media/audio/ui/Lock.ogg
media/audio/ui/LowBattery.ogg
media/audio/ui/NFCFailure.ogg
media/audio/ui/NFCInitiated.ogg
media/audio/ui/NFCSuccess.ogg
media/audio/ui/NFCTransferComplete.ogg
media/audio/ui/NFCTransferInitiated.ogg
media/audio/ui/Trusted.ogg
media/audio/ui/Undock.ogg
media/audio/ui/Unlock.ogg
media/audio/ui/VideoRecord.ogg
media/audio/ui/VideoStop.ogg
media/audio/ui/WirelessChargingStarted.ogg
media/audio/ui/audio_end.ogg
media/audio/ui/audio_initiate.ogg
media/audio/ui/camera_click.ogg
media/audio/ui/camera_focus.ogg
media/bootanimation.zip
priv-app/CarrierServices/CarrierServices.apk
priv-app/CarrierSetup/CarrierSetup.apk
priv-app/ConfigUpdater/ConfigUpdater.apk
priv-app/GmsCoreSetupPrebuilt/GmsCoreSetupPrebuilt.apk
priv-app/GoogleBackupTransport/GoogleBackupTransport.apk
priv-app/GoogleContacts/GoogleContacts.apk
priv-app/GoogleDialer/GoogleDialer.apk
priv-app/GoogleExtServices/GoogleExtServices.apk
priv-app/GoogleFeedback/GoogleFeedback.apk
priv-app/GoogleOneTimeInitializer/GoogleOneTimeInitializer.apk
priv-app/GooglePackageInstaller/GooglePackageInstaller.apk
priv-app/GooglePartnerSetup/GooglePartnerSetup.apk
priv-app/GoogleRestore/GoogleRestore.apk
priv-app/GoogleServicesFramework/GoogleServicesFramework.apk
priv-app/Phonesky/Phonesky.apk
priv-app/Photos/Photos.apk
priv-app/PrebuiltGmsCore/PrebuiltGmsCore.apk
priv-app/StorageManagerGoogle/StorageManagerGoogle.apk
priv-app/TagGoogle/TagGoogle.apk
priv-app/Turbo/Turbo.apk
priv-app/Velvet/Velvet.apk
priv-app/WellbeingPrebuilt/WellbeingPrebuilt.apk
product/etc/fonts_customization.xml
product/fonts/ArbutusSlab-Regular.ttf
product/fonts/GoogleSans-Bold.ttf
product/fonts/GoogleSans-BoldItalic.ttf
product/fonts/GoogleSans-Italic.ttf
product/fonts/GoogleSans-Medium.ttf
product/fonts/GoogleSans-MediumItalic.ttf
product/fonts/GoogleSans-Regular.ttf
product/fonts/Lato-Bold.ttf
product/fonts/Lato-BoldItalic.ttf
product/fonts/Lato-Italic.ttf
product/fonts/Lato-Medium.ttf
product/fonts/Lato-MediumItalic.ttf
product/fonts/Lato-Regular.ttf
product/fonts/Rubik-Bold.ttf
product/fonts/Rubik-BoldItalic.ttf
product/fonts/Rubik-Italic.ttf
product/fonts/Rubik-Medium.ttf
product/fonts/Rubik-MediumItalic.ttf
product/fonts/Rubik-Regular.ttf
product/fonts/ZillaSlab-Medium.ttf
product/fonts/ZillaSlab-MediumItalic.ttf
product/fonts/ZillaSlab-SemiBold.ttf
product/fonts/ZillaSlab-SemiBoldItalic.ttf
product/overlay/Amber/AmberThemeOverlay.apk
product/overlay/Blue/BlueThemeOverlay.apk
product/overlay/BlueGray/BlueGrayThemeOverlay.apk
product/overlay/BlueSky/BlueSkyThemeOverlay.apk
product/overlay/Brown/BrownThemeOverlay.apk
product/overlay/Cyan/CyanThemeOverlay.apk
product/overlay/DarkBlue/DarkBlueThemeOverlay.apk
product/overlay/DeepGray/DeepGrayThemeOverlay.apk
product/overlay/DeepOrange/DeepOrangeThemeOverlay.apk
product/overlay/FontGoogleSans/FontGoogleSansOverlay.apk
product/overlay/FontLato/FontLatoOverlay.apk
product/overlay/FontLatoGSans/FontLatoGSansOverlay.apk
product/overlay/FontRubik/FontRubikOverlay.apk
product/overlay/FontRubikGSans/FontRubikGSansOverlay.apk
product/overlay/FontZillaSlabGSans/FontZillaSlabGSansOverlay.apk
product/overlay/FontZillaSlabMedium/FontZillaSlabMediumOverlay.apk
product/overlay/Gray/GrayThemeOverlay.apk
product/overlay/Indigo/IndigoThemeOverlay.apk
product/overlay/LightGreen/LightGreenThemeOverlay.apk
product/overlay/Orange/OrangeThemeOverlay.apk
product/overlay/Pink/PinkThemeOverlay.apk
product/overlay/Pixel/PixelThemeOverlay.apk
product/overlay/PixelConfigOverlay2017.apk
product/overlay/PixelConfigOverlay2018.apk
product/overlay/PixelConfigOverlay2019Midyear.apk
product/overlay/PixelConfigOverlayCommon.apk
product/overlay/PixelOverlaySettings.apk
product/overlay/Purple/PurpleThemeOverlay.apk
product/overlay/Red/RedThemeOverlay.apk
product/overlay/Teal/TealThemeOverlay.apk
product/overlay/Yellow/YellowThemeOverlay.apk
product/overlay/framework-res__auto_generated_rro_product.apk
product/overlay/pixelrecents.apk
product/priv-app/HotwordEnrollmentOKGoogleWCD9340/HotwordEnrollmentOKGoogleWCD9340.apk
product/priv-app/HotwordEnrollmentXGoogleWCD9340/HotwordEnrollmentXGoogleWCD9340.apk
product/priv-app/MatchmakerPrebuiltPixel3/MatchmakerPrebuiltPixel3.apk
product/priv-app/NexusLauncherRelease/NexusLauncherRelease.apk
product/priv-app/PixelSetupWizard/PixelSetupWizard.apk
product/priv-app/PixelThemes/PixelThemes.apk
product/priv-app/SafetyHubPrebuilt/SafetyHubPrebuilt.apk
product/priv-app/SettingsIntelligenceGooglePrebuilt/SettingsIntelligenceGooglePrebuilt.apk
product/priv-app/SetupWizardPrebuilt/SetupWizardPrebuilt.apk
product/priv-app/WallpaperPickerGooglePrebuilt/WallpaperPickerGooglePrebuilt.apk
EOF
}

# Backup/Restore using /sdcard if the installed GApps size plus a buffer for other addon.d backups (204800=200MB) is larger than /tmp
installed_gapps_size_kb=$(grep "^installed_gapps_size_kb" $TMP/gapps.prop | cut -d '=' -f 2)
if [ ! "$installed_gapps_size_kb" ]; then
  installed_gapps_size_kb="$(cd $SYS; size=0; for n in $(du -ak $(list_files) | cut -f 1); do size=$((size+n)); done; echo "$size")"
  echo "installed_gapps_size_kb=$installed_gapps_size_kb" >> $TMP/gapps.prop
fi

free_tmp_size_kb=$(grep "^free_tmp_size_kb" $TMP/gapps.prop | cut -d '=' -f 2)
if [ ! "$free_tmp_size_kb" ]; then
  free_tmp_size_kb="$(echo $(df -k $TMP | tail -n 1) | cut -d ' ' -f 4)"
  echo "free_tmp_size_kb=$free_tmp_size_kb" >> $TMP/gapps.prop
fi

buffer_size_kb=204800
if [ $((installed_gapps_size_kb + buffer_size_kb)) -ge "$free_tmp_size_kb" ]; then
  C=/sdcard/tmp-gapps
fi

case "$1" in
  backup)
    list_files | while read -r FILE DUMMY; do
      backup_file "$S"/"$FILE"
    done
  ;;
  restore)
    list_files | while read -r FILE REPLACEMENT; do
      R=""
      [ -n "$REPLACEMENT" ] && R="$S/$REPLACEMENT"
      [ -f "$C/$S/$FILE" ] && restore_file "$S"/"$FILE" "$R"
    done
  ;;
  pre-backup)
    # Stub
  ;;
  post-backup)
    # Stub
  ;;
  pre-restore)
    # Remove Stock/AOSP apps (from GApps Installer)
    rm -rf $SYS/app/Bolt && rm -rf $SYS/product/app/Bolt && rm -rf /product/app/Bolt
    rm -rf $SYS/app/Browser && rm -rf $SYS/product/app/Browser && rm -rf /product/app/Browser
    rm -rf $SYS/app/Browser2 && rm -rf $SYS/product/app/Browser2 && rm -rf /product/app/Browser2
    rm -rf $SYS/app/BrowserIntl && rm -rf $SYS/product/app/BrowserIntl && rm -rf /product/app/BrowserIntl
    rm -rf $SYS/app/BrowserProviderProxy && rm -rf $SYS/product/app/BrowserProviderProxy && rm -rf /product/app/BrowserProviderProxy
    rm -rf $SYS/app/Chromium && rm -rf $SYS/product/app/Chromium && rm -rf /product/app/Chromium
    rm -rf $SYS/app/Fluxion && rm -rf $SYS/product/app/Fluxion && rm -rf /product/app/Fluxion
    rm -rf $SYS/app/Gello && rm -rf $SYS/product/app/Gello && rm -rf /product/app/Gello
    rm -rf $SYS/app/Jelly && rm -rf $SYS/product/app/Jelly && rm -rf /product/app/Jelly
    rm -rf $SYS/app/PABrowser && rm -rf $SYS/product/app/PABrowser && rm -rf /product/app/PABrowser
    rm -rf $SYS/app/PA_Browser && rm -rf $SYS/product/app/PA_Browser && rm -rf /product/app/PA_Browser
    rm -rf $SYS/app/YuBrowser && rm -rf $SYS/product/app/YuBrowser && rm -rf /product/app/YuBrowser
    rm -rf $SYS/priv-app/BLUOpera && rm -rf $SYS/product/priv-app/BLUOpera && rm -rf /product/priv-app/BLUOpera
    rm -rf $SYS/priv-app/BLUOperaPreinstall && rm -rf $SYS/product/priv-app/BLUOperaPreinstall && rm -rf /product/priv-app/BLUOperaPreinstall
    rm -rf $SYS/priv-app/Browser && rm -rf $SYS/product/priv-app/Browser && rm -rf /product/priv-app/Browser
    rm -rf $SYS/priv-app/BrowserIntl && rm -rf $SYS/product/priv-app/BrowserIntl && rm -rf /product/priv-app/BrowserIntl
    rm -rf $SYS/app/Calculator && rm -rf $SYS/product/app/Calculator && rm -rf /product/app/Calculator
    rm -rf $SYS/app/ExactCalculator && rm -rf $SYS/product/app/ExactCalculator && rm -rf /product/app/ExactCalculator
    rm -rf $SYS/app/FineOSCalculator && rm -rf $SYS/product/app/FineOSCalculator && rm -rf /product/app/FineOSCalculator
    rm -rf $SYS/app/Calendar && rm -rf $SYS/product/app/Calendar && rm -rf /product/app/Calendar
    rm -rf $SYS/app/FineOSCalendar && rm -rf $SYS/product/app/FineOSCalendar && rm -rf /product/app/FineOSCalendar
    rm -rf $SYS/app/MonthCalendarWidget && rm -rf $SYS/product/app/MonthCalendarWidget && rm -rf /product/app/MonthCalendarWidget
    rm -rf $SYS/priv-app/Calendar && rm -rf $SYS/product/priv-app/Calendar && rm -rf /product/priv-app/Calendar
    rm -rf $SYS/app/DeskClock && rm -rf $SYS/product/app/DeskClock && rm -rf /product/app/DeskClock
    rm -rf $SYS/app/DeskClock2 && rm -rf $SYS/product/app/DeskClock2 && rm -rf /product/app/DeskClock2
    rm -rf $SYS/app/FineOSDeskClock && rm -rf $SYS/product/app/FineOSDeskClock && rm -rf /product/app/FineOSDeskClock
    rm -rf $SYS/app/OmniClockOSS && rm -rf $SYS/product/app/OmniClockOSS && rm -rf /product/app/OmniClockOSS
    rm -rf $SYS/priv-app/Contacts && rm -rf $SYS/product/priv-app/Contacts && rm -rf /product/priv-app/Contacts
    rm -rf $SYS/priv-app/FineOSContacts && rm -rf $SYS/product/priv-app/FineOSContacts && rm -rf /product/priv-app/FineOSContacts
    rm -rf $SYS/priv-app/FineOSDialer && rm -rf $SYS/product/priv-app/FineOSDialer && rm -rf /product/priv-app/FineOSDialer
    rm -rf $SYS/priv-app/OPInCallUI && rm -rf $SYS/product/priv-app/OPInCallUI && rm -rf /product/priv-app/OPInCallUI
    rm -rf $SYS/app/Email && rm -rf $SYS/product/app/Email && rm -rf /product/app/Email
    rm -rf $SYS/app/PrebuiltEmailGoogle && rm -rf $SYS/product/app/PrebuiltEmailGoogle && rm -rf /product/app/PrebuiltEmailGoogle
    rm -rf $SYS/priv-app/Email && rm -rf $SYS/product/priv-app/Email && rm -rf /product/priv-app/Email
    rm -rf $SYS/app/Exchange2 && rm -rf $SYS/product/app/Exchange2 && rm -rf /product/app/Exchange2
    rm -rf $SYS/priv-app/Exchange2 && rm -rf $SYS/product/priv-app/Exchange2 && rm -rf /product/priv-app/Exchange2
    rm -rf $SYS/priv-app/ExtServices && rm -rf $SYS/product/priv-app/ExtServices && rm -rf /product/priv-app/ExtServices
    rm -rf $SYS/app/ExtShared && rm -rf $SYS/product/app/ExtShared && rm -rf /product/app/ExtShared
    rm -rf $SYS/app/Gallery && rm -rf $SYS/product/app/Gallery && rm -rf /product/app/Gallery
    rm -rf $SYS/app/Gallery2 && rm -rf $SYS/product/app/Gallery2 && rm -rf /product/app/Gallery2
    rm -rf $SYS/app/MediaShortcuts && rm -rf $SYS/product/app/MediaShortcuts && rm -rf /product/app/MediaShortcuts
    rm -rf $SYS/app/MotGallery && rm -rf $SYS/product/app/MotGallery && rm -rf /product/app/MotGallery
    rm -rf $SYS/priv-app/FineOSGallery && rm -rf $SYS/product/priv-app/FineOSGallery && rm -rf /product/priv-app/FineOSGallery
    rm -rf $SYS/priv-app/Gallery && rm -rf $SYS/product/priv-app/Gallery && rm -rf /product/priv-app/Gallery
    rm -rf $SYS/priv-app/Gallery2 && rm -rf $SYS/product/priv-app/Gallery2 && rm -rf /product/priv-app/Gallery2
    rm -rf $SYS/priv-app/GalleryX && rm -rf $SYS/product/priv-app/GalleryX && rm -rf /product/priv-app/GalleryX
    rm -rf $SYS/priv-app/MediaShortcuts && rm -rf $SYS/product/priv-app/MediaShortcuts && rm -rf /product/priv-app/MediaShortcuts
    rm -rf $SYS/priv-app/MiuiGallery && rm -rf $SYS/product/priv-app/MiuiGallery && rm -rf /product/priv-app/MiuiGallery
    rm -rf $SYS/priv-app/MotGallery && rm -rf $SYS/product/priv-app/MotGallery && rm -rf /product/priv-app/MotGallery
    rm -rf $SYS/priv-app/SnapdragonGallery && rm -rf $SYS/product/priv-app/SnapdragonGallery && rm -rf /product/priv-app/SnapdragonGallery
    rm -rf $SYS/app/LatinIME && rm -rf $SYS/product/app/LatinIME && rm -rf /product/app/LatinIME
    rm -rf $SYS/app/MzInput && rm -rf $SYS/product/app/MzInput && rm -rf /product/app/MzInput
    rm -rf $SYS/app/OpenWnn && rm -rf $SYS/product/app/OpenWnn && rm -rf /product/app/OpenWnn
    rm -rf $SYS/priv-app/BLUTouchPal && rm -rf $SYS/product/priv-app/BLUTouchPal && rm -rf /product/priv-app/BLUTouchPal
    rm -rf $SYS/priv-app/BLUTouchPalPortuguesebrPack && rm -rf $SYS/product/priv-app/BLUTouchPalPortuguesebrPack && rm -rf /product/priv-app/BLUTouchPalPortuguesebrPack
    rm -rf $SYS/priv-app/BLUTouchPalSpanishLatinPack && rm -rf $SYS/product/priv-app/BLUTouchPalSpanishLatinPack && rm -rf /product/priv-app/BLUTouchPalSpanishLatinPack
    rm -rf $SYS/priv-app/MzInput && rm -rf $SYS/product/priv-app/MzInput && rm -rf /product/priv-app/MzInput
    rm -rf $SYS/app/CMHome && rm -rf $SYS/product/app/CMHome && rm -rf /product/app/CMHome
    rm -rf $SYS/app/CustomLauncher3 && rm -rf $SYS/product/app/CustomLauncher3 && rm -rf /product/app/CustomLauncher3
    rm -rf $SYS/app/EasyLauncher && rm -rf $SYS/product/app/EasyLauncher && rm -rf /product/app/EasyLauncher
    rm -rf $SYS/app/FineOSHome && rm -rf $SYS/product/app/FineOSHome && rm -rf /product/app/FineOSHome
    rm -rf $SYS/app/Fluctuation && rm -rf $SYS/product/app/Fluctuation && rm -rf /product/app/Fluctuation
    rm -rf $SYS/app/FlymeLauncher && rm -rf $SYS/product/app/FlymeLauncher && rm -rf /product/app/FlymeLauncher
    rm -rf $SYS/app/FlymeLauncherIntl && rm -rf $SYS/product/app/FlymeLauncherIntl && rm -rf /product/app/FlymeLauncherIntl
    rm -rf $SYS/app/Launcher2 && rm -rf $SYS/product/app/Launcher2 && rm -rf /product/app/Launcher2
    rm -rf $SYS/app/Launcher3 && rm -rf $SYS/product/app/Launcher3 && rm -rf /product/app/Launcher3
    rm -rf $SYS/app/LiquidLauncher && rm -rf $SYS/product/app/LiquidLauncher && rm -rf /product/app/LiquidLauncher
    rm -rf $SYS/app/Paclauncher && rm -rf $SYS/product/app/Paclauncher && rm -rf /product/app/Paclauncher
    rm -rf $SYS/app/SlimLauncher && rm -rf $SYS/product/app/SlimLauncher && rm -rf /product/app/SlimLauncher
    rm -rf $SYS/app/Trebuchet && rm -rf $SYS/product/app/Trebuchet && rm -rf /product/app/Trebuchet
    rm -rf $SYS/priv-app/CMHome && rm -rf $SYS/product/priv-app/CMHome && rm -rf /product/priv-app/CMHome
    rm -rf $SYS/priv-app/CustomLauncher3 && rm -rf $SYS/product/priv-app/CustomLauncher3 && rm -rf /product/priv-app/CustomLauncher3
    rm -rf $SYS/priv-app/EasyLauncher && rm -rf $SYS/product/priv-app/EasyLauncher && rm -rf /product/priv-app/EasyLauncher
    rm -rf $SYS/priv-app/Fluctuation && rm -rf $SYS/product/priv-app/Fluctuation && rm -rf /product/priv-app/Fluctuation
    rm -rf $SYS/priv-app/FlymeLauncher && rm -rf $SYS/product/priv-app/FlymeLauncher && rm -rf /product/priv-app/FlymeLauncher
    rm -rf $SYS/priv-app/FlymeLauncherIntl && rm -rf $SYS/product/priv-app/FlymeLauncherIntl && rm -rf /product/priv-app/FlymeLauncherIntl
    rm -rf $SYS/priv-app/Launcher2 && rm -rf $SYS/product/priv-app/Launcher2 && rm -rf /product/priv-app/Launcher2
    rm -rf $SYS/priv-app/Launcher3 && rm -rf $SYS/product/priv-app/Launcher3 && rm -rf /product/priv-app/Launcher3
    rm -rf $SYS/priv-app/LiquidLauncher && rm -rf $SYS/product/priv-app/LiquidLauncher && rm -rf /product/priv-app/LiquidLauncher
    rm -rf $SYS/priv-app/MiuiHome && rm -rf $SYS/product/priv-app/MiuiHome && rm -rf /product/priv-app/MiuiHome
    rm -rf $SYS/priv-app/Nox && rm -rf $SYS/product/priv-app/Nox && rm -rf /product/priv-app/Nox
    rm -rf $SYS/priv-app/Paclauncher && rm -rf $SYS/product/priv-app/Paclauncher && rm -rf /product/priv-app/Paclauncher
    rm -rf $SYS/priv-app/SlimLauncher && rm -rf $SYS/product/priv-app/SlimLauncher && rm -rf /product/priv-app/SlimLauncher
    rm -rf $SYS/priv-app/Trebuchet && rm -rf $SYS/product/priv-app/Trebuchet && rm -rf /product/priv-app/Trebuchet
    rm -rf $SYS/app/messaging && rm -rf $SYS/product/app/messaging && rm -rf /product/app/messaging
    rm -rf $SYS/priv-app/FineOSMms && rm -rf $SYS/product/priv-app/FineOSMms && rm -rf /product/priv-app/FineOSMms
    rm -rf $SYS/priv-app/Mms && rm -rf $SYS/product/priv-app/Mms && rm -rf /product/priv-app/Mms
    rm -rf $SYS/app/PackageInstaller && rm -rf $SYS/product/app/PackageInstaller && rm -rf /product/app/PackageInstaller
    rm -rf $SYS/priv-app/PackageInstaller && rm -rf $SYS/product/priv-app/PackageInstaller && rm -rf /product/priv-app/PackageInstaller
    rm -rf $SYS/priv-app/packageinstaller && rm -rf $SYS/product/priv-app/packageinstaller && rm -rf /product/priv-app/packageinstaller
    rm -rf $SYS/app/PicoTts && rm -rf $SYS/product/app/PicoTts && rm -rf /product/app/PicoTts
    rm -rf $SYS/lib/libttscompat.so && rm -rf $SYS/product/lib/libttscompat.so && rm -rf /product/lib/libttscompat.so
    rm -rf $SYS/lib/libttspico.so && rm -rf $SYS/product/lib/libttspico.so && rm -rf /product/lib/libttspico.so
    rm -rf $SYS/priv-app/PicoTts && rm -rf $SYS/product/priv-app/PicoTts && rm -rf /product/priv-app/PicoTts
    rm -rf $SYS/tts && rm -rf $SYS/product/tts && rm -rf /product/tts
    rm -rf $SYS/app/BuiltInPrintService && rm -rf $SYS/product/app/BuiltInPrintService && rm -rf /product/app/BuiltInPrintService
    rm -rf $SYS/app/PrintRecommendationService && rm -rf $SYS/product/app/PrintRecommendationService && rm -rf /product/app/PrintRecommendationService
    rm -rf $SYS/app/Provision && rm -rf $SYS/product/app/Provision && rm -rf /product/app/Provision
    rm -rf $SYS/priv-app/Provision && rm -rf $SYS/product/priv-app/Provision && rm -rf /product/priv-app/Provision
    rm -rf $SYS/priv-app/StorageManager && rm -rf $SYS/product/priv-app/StorageManager && rm -rf /product/priv-app/StorageManager
    rm -rf $SYS/priv-app/Tag && rm -rf $SYS/product/priv-app/Tag && rm -rf /product/priv-app/Tag
    rm -rf $SYS/app/WallpaperPicker && rm -rf $SYS/product/app/WallpaperPicker && rm -rf /product/app/WallpaperPicker
    rm -rf $SYS/app/WebView && rm -rf $SYS/product/app/WebView && rm -rf /product/app/WebView
    rm -rf $SYS/app/webview && rm -rf $SYS/product/app/webview && rm -rf /product/app/webview
    rm -rf $SYS/lib/libwebviewchromium.so && rm -rf $SYS/product/lib/libwebviewchromium.so && rm -rf /product/lib/libwebviewchromium.so
    rm -rf $SYS/lib64/libwebviewchromium.so && rm -rf $SYS/product/lib64/libwebviewchromium.so && rm -rf /product/lib64/libwebviewchromium.so

    # Remove 'other' apps (per installer.data)
    rm -rf $SYS/app/BookmarkProvider
    rm -rf $SYS/app/BooksStub
    rm -rf $SYS/app/CalendarGoogle
    rm -rf $SYS/app/CloudPrint
    rm -rf $SYS/app/DeskClockGoogle
    rm -rf $SYS/app/EditorsDocsStub
    rm -rf $SYS/app/EditorsSheetsStub
    rm -rf $SYS/app/EditorsSlidesStub
    rm -rf $SYS/app/Gmail
    rm -rf $SYS/app/Gmail2
    rm -rf $SYS/app/GoogleCalendar
    rm -rf $SYS/app/GoogleCloudPrint
    rm -rf $SYS/app/GoogleHangouts
    rm -rf $SYS/app/GoogleKeep
    rm -rf $SYS/app/GoogleLatinIme
    rm -rf $SYS/app/Keep
    rm -rf $SYS/app/NewsstandStub
    rm -rf $SYS/app/PartnerBookmarksProvider
    rm -rf $SYS/app/PrebuiltBugleStub
    rm -rf $SYS/app/PrebuiltKeepStub
    rm -rf $SYS/app/QuickSearchBox
    rm -rf $SYS/app/Vending
    rm -rf $SYS/priv-app/GmsCore
    rm -rf $SYS/priv-app/GmsCore_update
    rm -rf $SYS/priv-app/GoogleHangouts
    rm -rf $SYS/priv-app/GoogleNow
    rm -rf $SYS/priv-app/GoogleSearch
    rm -rf $SYS/priv-app/OneTimeInitializer
    rm -rf $SYS/priv-app/QuickSearchBox
    rm -rf $SYS/priv-app/Velvet_update
    rm -rf $SYS/priv-app/Vending

    # Remove 'priv-app' apps from 'app' (per installer.data)
    rm -rf $SYS/app/CanvasPackageInstaller
    rm -rf $SYS/app/ConfigUpdater
    rm -rf $SYS/app/GoogleBackupTransport
    rm -rf $SYS/app/GoogleFeedback
    rm -rf $SYS/app/GoogleLoginService
    rm -rf $SYS/app/GoogleOneTimeInitializer
    rm -rf $SYS/app/GooglePartnerSetup
    rm -rf $SYS/app/GoogleServicesFramework
    rm -rf $SYS/app/OneTimeInitializer
    rm -rf $SYS/app/Phonesky
    rm -rf $SYS/app/PrebuiltGmsCore
    rm -rf $SYS/app/SetupWizard
    rm -rf $SYS/app/Velvet

    # Remove 'required' apps (per installer.data)
    rm -rf $SYS/app/LatinIME/lib//libjni_keyboarddecoder.so
    rm -rf $SYS/app/LatinIME/lib//libjni_latinimegoogle.so
    rm -rf $SYS/lib/libjni_keyboarddecoder.so
    rm -rf $SYS/lib/libjni_latinimegoogle.so
    rm -rf $SYS/lib64/libjni_keyboarddecoder.so
    rm -rf $SYS/lib64/libjni_latinimegoogle.so

    # Remove 'user requested' apps (from gapps-config)

  ;;
  post-restore)
    # Recreate required symlinks (from GApps Installer)
    install -d "/system_root/system/app/MarkupGoogle/lib/arm64"
    ln -sfn "/system_root/system/lib64/libsketchology_native.so" "/system_root/system/app/MarkupGoogle/lib/arm64/libsketchology_native.so"
    install -d "$SYS/app/FaceLock/lib/arm64"
    ln -sfn "$SYS/lib64/libfacenet.so" "$SYS/app/FaceLock/lib/arm64/libfacenet.so"

    # Apply build.prop changes (from GApps Installer)
    sed -i "s/ro.error.receiver.system.apps=.*/ro.error.receiver.system.apps=com.google.android.gms/g" $SYS/build.prop

    # Re-pre-ODEX APKs (from GApps Installer)

    # Remove any empty folders we may have created during the removal process
    for i in $SYS/app $SYS/priv-app $SYS/vendor/pittpatt $SYS/usr/srec; do
      if [ -d $i ]; then
        find $i -type d -exec rmdir -p '{}' \+ 2>/dev/null;
      fi
    done;
    # Fix ownership/permissions and clean up after backup and restore from /sdcard
    find $SYS/vendor/pittpatt -type d -exec chown 0:2000 '{}' \; # Change pittpatt folders to root:shell per Google Factory Settings
    for i in $(list_files); do
      chown root:root "$SYS/$i"
      chmod 644 "$SYS/$i"
      chmod 755 "$(dirname "$SYS/$i")"
        if [ "$API" -ge "26" ]; then # Android 8.0+ uses 0600 for its permission on build.prop
          chmod 600 "$SYS/build.prop"
        fi
    done
    rm -rf /sdcard/tmp-gapps
  ;;
esac
